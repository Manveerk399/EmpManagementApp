import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const PayrollSettings = () => {
  return (
    <View>
      <Text>PayrollSettings</Text>
    </View>
  )
}

export default PayrollSettings

const styles = StyleSheet.create({})