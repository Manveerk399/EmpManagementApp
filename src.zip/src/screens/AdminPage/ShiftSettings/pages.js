export const pages =[
    // {
    //     name:'General',
    //     link:'shiftgeneral',
    //     description:'Manage the general settings of shifts of your company.'
    // },
    {
        name:'Shifts',
        link:'shiftscontrol',
        description:'Define and manage the different type of shifts available in your company.'
    }
]