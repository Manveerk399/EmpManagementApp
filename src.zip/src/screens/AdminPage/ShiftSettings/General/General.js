import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const General = () => {
  return (
    <View>
      <Text>General</Text>
    </View>
  )
}

export default General

const styles = StyleSheet.create({})