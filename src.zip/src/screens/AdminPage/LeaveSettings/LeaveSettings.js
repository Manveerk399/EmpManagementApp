import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const LeaveSettings = () => {
  return (
    <View>
      <Text>LeaveSettings</Text>
    </View>
  )
}

export default LeaveSettings

const styles = StyleSheet.create({})