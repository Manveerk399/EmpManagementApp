import { View, Text } from 'react-native'
import React from 'react'

const AccessControl=() => {
  return (
    <View>
      <Text>AccessControl</Text>
    </View>
  )
}

export default AccessControl