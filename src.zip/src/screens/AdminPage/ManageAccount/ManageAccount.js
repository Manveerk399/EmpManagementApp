import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ManageAccount = () => {
  return (
    <View>
      <Text>ManageAccount</Text>
    </View>
  )
}

export default ManageAccount

const styles = StyleSheet.create({})